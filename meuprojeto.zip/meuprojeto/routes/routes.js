const express = require("express")
const router = express.Router()

router.get("/login", (req, res) => {
  res.render("login", { layout: "login" })
})

router.get("/usuario", (req, res) => {
  res.render("usuario", { layout: "usuario" })
})

router.get("/contato", (req, res) => {
    res.render("contato")
})

router.get("/sobre", (req, res) => {
    res.render("sobre")
})

module.exports = router